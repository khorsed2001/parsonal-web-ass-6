# B9A6-Retro-Forum


## [ Private Repo Link](https://classroom.github.com/a/M685dkpe)

Click here for the private repo: [https://classroom.github.com/a/M685dkpe](https://classroom.github.com/a/M685dkpe)



# API

LatestPosts: - https://openapi.programming-hero.com/api/retro-forum/latest-posts

AllPosts: - https://openapi.programming-hero.com/api/retro-forum/posts

## PostSearchByQuery

PostByQuery: -  https://openapi.programming-hero.com/api/retro-forum/posts?category=categoryName


### Example

PostByQuery: - https://openapi.programming-hero.com/api/retro-forum/posts?category=coding




